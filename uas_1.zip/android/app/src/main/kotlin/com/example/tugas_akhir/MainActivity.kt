package com.example.tugas_akhir

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
